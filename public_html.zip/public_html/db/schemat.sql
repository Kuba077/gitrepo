CREATE TABLE users (
    uid INTEGER PRIMARY KEY NOT NULL,
    login CHAR(20) UNIQUE NOT NULL,
    haslo CHAR(50) NOT NULL,
    email CHAR(40) UNIQUE NOT NULL,
    datad INT NOT NULL
);
INSERT INTO users VALUES (NULL, 'admin', 'haslo', 'admin@home.net', time());

CREATE TABLE klasy
(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    klasa TEXT,
    rok_naboru INTEGER,
    rok_matury INTEGER
);

CREATE TABLE uczniowie
(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    imie TEXT,
    nazwisko TEXT,
    plec BOOLEAN,
    id_klasa INTEGER NOT NULL,
    FOREIGN KEY (id_klasa) REFERENCES klasy(id)
    ON DELETE CASCADE ON UPDATE NO ACTION
);


