#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  slonce.py
#  
from turtle import *
color('blue', 'red')
begin_fill()
forward(200)
right(90)
forward(200)
right(90)
forward(200)
right(90)
forward(200)
right(90)
end_fill()
done()
