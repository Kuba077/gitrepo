<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<!DOCTYPE html>
<html lang="pl">
<?php include('header.inc.php')?>
<body>
  <!-- brak java scriptu -->
  <noscript>
    Do pełnej funkcjonalności strony potrzebujesz włączonej obsługi skryptów.
    Tu znajdziesz <a href="https://www.enable-javascript.com/pl/" target="_blank">
    instrukcje, które pozwolą Ci włączyć skrypty w Twojej przeglądarce</a>.
  </noscript>

  <!-- nieaktualna przeglądarka, zob. dostosowanie: https://browser-update.org/customize.html -->
  <script>
    var $buoop = {notify:{e:-6,f:-4,o:-4,s:-2,c:-4},insecure:true,api:5};
    function $buo_f(){
      var e = document.createElement("script");
      e.src = "http://browser-update.org/update.min.js";
      document.body.appendChild(e);
    };
    try {document.addEventListener("DOMContentLoaded", $buo_f,false)}
    catch(e){window.attachEvent("onload", $buo_f)}
  </script>
  <!-- Nagłówek strony: menu, logo, breadcrumbs itp. -->
    <?php include('nav.inc.php');?>
  <!-- Treść główna -->
  <!-- Karuzela  -->
  <?php include('carousel.inc.php');?>
  <div class="container mt-4 mb-4">
    <div class="row">
      <div class="col-12">
      <h1><?php get_page_title(); ?></h1>	
      </div>
      <div class="col-8" style="background-color: rgb(68, 68, 68); color: white;">
      <?php get_page_content(); ?>
					<p class="page-meta text-primary">Opublikowano &nbsp;<span><?php get_page_date('F jS, Y'); ?></span></p>
      </div>
      <div class="col-4 text-danger">
        <h3>Gorąco polecamy:</h3>
        <?php get_component('sidebar');	?>
      </div>
    </div>
  </div>
  <!-- Stopka -->
<?php include('footer.inc.php');?>
</body>
</html>
