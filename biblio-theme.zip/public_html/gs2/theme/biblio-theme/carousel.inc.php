<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" style="margin-top: 100px;">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="w-100" src="<?php get_theme_url();?>/img/banner.png" alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="w-100" src="<?php get_theme_url();?>/img/banner2.jpg" alt="Second slide">
      </div>
    </div>
  </div>