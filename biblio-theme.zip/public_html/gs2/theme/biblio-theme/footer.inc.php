<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<footer class="page-footer font-small blue">
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">
  <p><?php echo date('Y'); ?> - <strong><?php get_site_name(); ?></strong></p>
			<p>
				Biblio Theme by <a href="httpL//lo1.sandomierz.pl">Jakub, Adam, Michał</a><br />
				<?php get_site_credits(); ?>
			</p>
  </div>
</footer>

  <!-- jQuery library -->
  <script src="<?php get_theme_url();?>/js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap JavaScript and Popper JS (https://popper.js.org) -->
  <script src="<?php get_theme_url();?>/js/bootstrap.bundle.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php get_theme_url();?>/js/mdb.min.js"></script>

  <!-- Szybkość karuzeli -->
  <script type="text/javascript">
    $('.carousel').carousel({
      interval: 4000
    })
  </script>
